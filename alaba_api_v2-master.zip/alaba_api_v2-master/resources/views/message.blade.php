<p>buyer {{$username}}</p>
<p>{{$content}}</p>
<p>{{$product_name}}</p>
