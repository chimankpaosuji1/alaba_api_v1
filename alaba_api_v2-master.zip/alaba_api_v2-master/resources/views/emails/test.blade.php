<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1>{{$title}}</h1>
</body>
</html>