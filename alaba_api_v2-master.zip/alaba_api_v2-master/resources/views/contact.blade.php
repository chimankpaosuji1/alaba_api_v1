<p>{{$content}}</p>
<p>{{$first_name}}</p>
<p>{{$last_name}}</p>
<p>{{$email}}</p>
<p>{{$phone}}</p>
