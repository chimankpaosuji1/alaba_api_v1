<p>Dear {{$username}}</p>

<p>Your enquiry concerning {{$product_name}} has been delivered  to the seller await the seller response</p>
