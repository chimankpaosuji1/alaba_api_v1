




<p>Dear {{$buyer_name}}</p>
<p>This is the reply from the seller on the product {{$product_name}}</p>
<p>Reply: {{$reply}}</p>
