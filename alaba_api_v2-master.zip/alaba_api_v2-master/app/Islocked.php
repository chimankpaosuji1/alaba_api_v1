<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Islocked extends Model
{
    //
}
